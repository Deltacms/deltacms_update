<?php
// Lexique du module du coeur Sitemap en espagnol
$text['core_sitemap']['index'][0] = 'Mapa del sitio';

?>