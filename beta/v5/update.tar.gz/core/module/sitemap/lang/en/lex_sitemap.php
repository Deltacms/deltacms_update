<?php
// Lexique du module du coeur Sitemap en anglais
$text['core_sitemap']['index'][0] = 'Site map';

?>