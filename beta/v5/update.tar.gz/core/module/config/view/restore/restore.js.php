/**
 * This file is part of DeltaCMS.
 */

$( document).ready(function() {

    /**
     * Aspect de la souris
    */
     $("#configRestoreSubmit").click(function(event) {
        $('body, .button').css('cursor', 'wait');
    });
    
});