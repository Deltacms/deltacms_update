<?php
// Lexique du module Guestbook en espagnol
$text['guestbook_view']['config'][0] = 'Título';
$text['guestbook_view']['config'][1] = 'No hay opción para este campo';
$text['guestbook_view']['config'][2] = 'Lista de valores separados por comas (valor1,valor2,...)';
$text['guestbook_view']['config'][3] = 'Campo obligatorio';
$text['guestbook_view']['config'][4] = 'Atrás';
$text['guestbook_view']['config'][5] = 'Administrar datos';
$text['guestbook_view']['config'][6] = 'Configuración';
$text['guestbook_view']['config'][9] = 'Enviar por correo los datos ingresados:';
$text['guestbook_view']['config'][10] = 'Seleccione al menos un grupo, usuario o ingrese un correo electrónico. Su servidor debe permitir el envío de correo.';
$text['guestbook_view']['config'][11] = 'Dejar vacío para mantener el texto predeterminado.';
$text['guestbook_view']['config'][12] = 'Asunto del correo';
$text['guestbook_view']['config'][13] = 'A grupos desde ';
$text['guestbook_view']['config'][14] = 'Editores = editores + administradores<br/> Miembros = miembros + editores + administradores';
$text['guestbook_view']['config'][15] = 'Tiene un miembro';
$text['guestbook_view']['config'][16] = 'A una dirección de correo electrónico';
$text['guestbook_view']['config'][17] = 'Un correo electrónico o lista de correo';
$text['guestbook_view']['config'][18] = 'Responder al remitente desde el correo de notificación';
$text['guestbook_view']['config'][19] = 'Esta opción le permite responder directamente al remitente del mensaje si el remitente ha indicado un correo electrónico válido.';
$text['guestbook_view']['config'][20] = 'Seleccionar tipo de firma';
$text['guestbook_view']['config'][21] = 'Seleccionar logo del sitio';
$text['guestbook_view']['config'][22] = 'Logotipo';
$text['guestbook_view']['config'][23] = 'Seleccionar ancho de logo';
$text['guestbook_view']['config'][24] = 'Redireccionamiento después del envío del formulario';
$text['guestbook_view']['config'][25] = 'Seleccione una página del sitio:';
$text['guestbook_view']['config'][26] = 'Validar un captcha para enviar el formulario.';
$text['guestbook_view']['config'][27] = 'Lista de campos';
$text['guestbook_view']['config'][28] = 'El formulario no contiene ningún campo.';
$text['guestbook_view']['config'][29] = 'Número de versión';
$text['guestbook_view']['config'][30] = 'Guardar';
$text['guestbook_view']['config'][38] = 'Anote en el campo de archivo la etiqueta del tipo y tamaño de los archivos autorizados. Las comprobaciones se realizan en archivos jpg, png, pdf y zip, pero no en archivos txt. Precaución !';
$text['guestbook_view']['config'][39] = 'Ayuda';
$text['guestbook_view']['config'][40] = 'module/guestbook/view/config/config.help_en.html';
$text['guestbook_view']['config'][41] = 'Marque la casilla de aceptación de las condiciones de uso de datos personales';
$text['guestbook_view']['config'][42] = 'Si su cuestionario se refiere a datos personales, el RGPD en ciertos países requiere la aceptación de sus condiciones de uso por parte del participante. También debe explicar por qué está utilizando estos datos. El texto asociado debe actualizarse en la configuración de ubicación.';
$text['guestbook_view']['config'][43] = 'Textos ';
$text['guestbook_view']['config'][44] = 'Para evitar que el correo electrónico sea considerado spam, es preferible elegir una firma con el nombre del sitio';
$text['guestbook_view']['texts'][0] = 'Atrás';
$text['guestbook_view']['texts'][1] = 'Guardar';
$text['guestbook_view']['texts'][2] = 'Adapte estos textos al idioma de sus visitantes ';
$text['guestbook_view']['texts'][3] = 'N° de versión ';
$text['guestbook_view']['data'][0] = 'Atrás';
$text['guestbook_view']['data'][1] = 'Borrar todo';
$text['guestbook_view']['data'][2] = 'Exportar CSV';
$text['guestbook_view']['data'][3] = 'Data';
$text['guestbook_view']['data'][4] = 'Sin datos';
$text['guestbook_view']['data'][5] = 'Número de versión';
$text['guestbook_view']['data'][6] = "¿Está seguro de que desea eliminar estos datos?";
$text['guestbook_view']['data'][7] = "¿Está seguro de que desea eliminar todos los datos?";
$text['guestbook_view']['index'][0] = 'Enviar';
$text['guestbook_view']['index'][1] = 'El formulario no contiene ningún campo.';
$text['guestbook_view']['index'][2] = 'es';
$text['guestbook_view']['index'][3] = 'Aún no hay mensaje';
$text['guestbook']['config'][0] = 'Cambios guardados';
$text['guestbook']['config'][1] = 'Configuración del módulo';
$text['guestbook']['texts'][0] = 'Textos visibles para un visitante';
$text['guestbook']['texts'][1] = 'Textos registrados';
$text['guestbook']['data'][0] = 'Datos registrados';
$text['guestbook']['export2csv'][0] = 'Acción no permitida';
$text['guestbook']['export2csv'][1] = 'Exportación CSV realizada en el administrador de archivos<br />bajo el nombre ';
$text['guestbook']['export2csv'][2] = 'No hay datos para exportar';
$text['guestbook']['deleteall'][0] = 'Acción no permitida';
$text['guestbook']['deleteall'][1] = 'Datos eliminados';
$text['guestbook']['deleteall'][2] = 'No hay datos para eliminar';
$text['guestbook']['delete'][0] = 'Acción no permitida';
$text['guestbook']['delete'][1] = 'Datos eliminados';
$text['guestbook']['index'][0] = 'Captcha no válido';
$text['guestbook']['index'][1] = 'Nuevo mensaje de su sitio';
$text['guestbook']['index'][2] = 'Nuevo mensaje de la página "';
$text['guestbook']['index'][3] = 'Formulario enviado';
$text['guestbook']['index'][9] = 'falló el mensaje no se envía porque ';
$text['guestbook']['index'][10] = 'Fecha';
$text['guestbook']['index'][12] = ' Complete el Captcha ';
$text['guestbook']['index'][13] = 'Mostrar u ocultar formulario';
// Initialisation de flatpickr
$lang_flatpickr = 'es';
// Langue d'administration pour tinymce
$lang_admin = 'es';
// Selects
$signature = [
	'text' => 'Nombre del sitio',
	'logo' => 'Logo del sitio'
];
if( $param === 'guestbook_view'){
	$groupNews = [
		self::GROUP_MEMBER => 'Miembro',
		self::GROUP_EDITOR => 'Editor',
		self::GROUP_MODERATOR => 'Moderador',
		self::GROUP_ADMIN => 'Administrador'
	];
	$types = [
		$module::TYPE_TEXT => 'Campo de texto',
		$module::TYPE_TEXTAREA => 'Campo de texto grande',
		$module::TYPE_MAIL => 'Campo de correo'
	];
}
?>
