<?php
// Lexique du module redirection en espagnol
$text['redirection_view']['config'][0] = 'Atrás';
$text['redirection_view']['config'][1] = 'Guardar';
$text['redirection_view']['config'][2] = 'Enlace de redirección';
$text['redirection_view']['config'][3] = 'El enlace de redirección puede contener una URL estándar o apuntar al ancla de una página en el sitio <em>(/pagina#ancla) </em> ; <em>(/?pagina#ancla)</em>';
$text['redirection_view']['config'][4] = 'Redireccionamiento';
$text['redirection_view']['config'][5] = 'Estadísticas';
$text['redirection_view']['config'][6] = 'Número de redireccionamientos';
$text['redirection_view']['config'][7] = 'Número de versión';
$text['redirection_view']['config'][8] = 'Ayuda';
$text['redirection_view']['config'][9] = 'module/redirection/view/config/config.help_en.html';
$text['redirection_view']['index'][0] = 'SÍ: editar página | NO: pruebe la redirección.';
$text['redirection']['config'][0] = 'Cambios guardados';
$text['redirection']['config'][1] = 'Configuración del módulo';
?>