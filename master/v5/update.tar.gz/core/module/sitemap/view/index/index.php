<?php
	echo "<div  id='siteMap'>";
	echo $module::$siteMap;
	echo "</div>";
